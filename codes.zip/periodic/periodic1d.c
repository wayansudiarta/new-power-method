/* Periodic FDTD 1D
   I Wayan Sudiarta
   New Scheme for determining eigenstate any desired level
   with periodic boundary condition
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define NX 100   
#define NT 100000

int main(int argc, char *argv[])
{
	long int i, n, m;
	double psi[NX+1];
	double psinew[NX+1];
	double pi = 2.0*asin(1.0);
	double temp, energy, oldenergy, de;
	double dx, dt, dx2;
	double dtdx2, Ep;
	FILE *outfile;
    long int NM;
	
    Ep = atof(argv[1]);
	
	dx = 0.01;
	dx2 = dx*dx;
	dt = 0.1*dx2;
	
	NM = (long int)1/(Ep*dt);
	dtdx2 = dt/(2*dx2);
	
	printf("%lf, ", Ep);
	
    // initial psi with random values
	// + periodic BC
	//srand(4567);
	srand(time(NULL)); // randomize seed

	for(i = 0; i < NX; i++){
        psi[i] = rand()/(double)RAND_MAX;
	}
    psi[NX] = psi[0];

    // Normalisasi
    temp = 0.0;
    for(i = 0; i < NX; i++){
        temp += psi[i]*psi[i];
    }
    temp = sqrt(temp*dx);
	for(i = 0; i <= NX; i++){
	   psi[i] = psi[i]/temp;
    }
	
	// Save psi0
	//outfile = fopen("psi0.dat", "w");
	//for(i = 0; i <= NX; i++){
	//	fprintf(outfile, "%le %le \n", i*dx, psi[i]);
	//}
	//fclose(outfile);
	
    // iteration
	oldenergy = 1.0E20;
	
	n = 0;
    do{
		n++;
		// apply exp(-t H), sebanyak t = NM delta t  
        for(m = 1; m <= NM; m++){
		    // Update psi i = 1...NX-1//
		    for(i = 1; i < NX; i++){
	            psinew[i] = psi[i];
			    psinew[i] += dtdx2*(psi[i-1] - 2*psi[i] + psi[i+1]);
		    }

            // Periodic Boundary 
	        psinew[0] = psi[0];
			psinew[0] += dtdx2*(psi[NX-1] - 2*psi[0] + psi[1]);
		    psinew[NX] = psinew[0];
			
			// save for next iteration
		    for(i = 0; i <= NX; i++){
			    psi[i] = psinew[i];
		    }
			//printf("%ld %ld\n", m, NM);
	    }
		
		// apply psinew =  H psi //
		for(i = 1; i < NX; i++){
		    psinew[i] = (-0.5/dx2)*(psi[i-1] - 2*psi[i] + psi[i+1]);
	    }
		psinew[0] = (-0.5/dx2)*(psi[NX-1] - 2*psi[0] + psi[1]);
		psinew[NX] = psinew[0];
	    
		// save for next iteration
	    for(i = 0; i <= NX; i++){
		    psi[i] = psinew[i];
	    }

        // Normalisasi
        temp = 0.0;
	    for(i = 0; i < NX; i++){
	       temp += psi[i]*psi[i];
        }
        temp = sqrt(temp*dx);
	    for(i = 0; i <= NX; i++){
	       psi[i] = psi[i]/temp;
        }
		// Compute Energy
	    energy = 0.0;
		for(i = 1; i < NX; i++){
		    energy += (-0.5/dx2)*(psi[i-1] - 2*psi[i] + psi[i+1])*psi[i]*dx;
		}
	    energy += (-0.5/dx2)*(psi[NX-1] - 2*psi[0] + psi[1])*psi[0]*dx;
		
		de = fabs(energy - oldenergy);
		oldenergy = energy;
		//printf("%ld, %lf \n", n, energy);

    }while(de > 1.0E-9);
	
	printf("final %ld, %lf \n", n, energy);
	

	//Save Results
	outfile = fopen("psi.dat", "w");
	for(i = 0; i <= NX; i++){
		fprintf(outfile, "%le, %le \n", i*dx, psi[i]);
	}
	fclose(outfile);
	
    return 0;	
}