/* AnyState FDTD 3D
   I Wayan Sudiarta
   New Scheme for determining eigenstate any desired level
   fdtd 3D
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define NX 20    
#define NT 100000

int main(int argc, char *argv[])
{
	long int i, j, k, n, m;
	double psi[NX+1][NX+1][NX+1];
	double psinew[NX+1][NX+1][NX+1];
	double pi = 2.0*asin(1.0);
	double temp, energy, oldenergy, de;
	double dx, dt, dx2, dx3;
	double dtdx2, Ep;
	FILE *outfile;
    long int NM;
	
    Ep = atof(argv[1]);
	
	dx = 0.05;
	dx2 = dx*dx;
	dx3 = dx*dx*dx;
	dt = 0.1*dx2;
	
	NM = (long int)1/(Ep*dt);
	dtdx2 = dt/(2*dx2);
	
	printf("%lf, ", Ep);
	
    // initial psi with random values
	//srand(4567);
	srand(time(NULL)); // randomize seed
	
	// set to zero
	for(i = 0; i <= NX; i++){
	for(j = 0; j <= NX; j++){
	for(k = 0; k <= NX; k++){
        psi[i][j][k] = 0.0;
	}}}
	
	for(i = 1; i < NX; i++){
	for(j = 1; j < NX; j++){
	for(k = 1; k < NX; k++){
        psi[i][j][k] = rand()/(double)RAND_MAX;
	}}}

	// Save psi0
	//outfile = fopen("psi0.dat", "w");
	//for(i = 0; i <= NX; i++){
	//	fprintf(outfile, "%le %le \n", i*dx, psi[i]);
	//}
	//fclose(outfile);
	
    // iteration
	oldenergy = 1.0E20;
	
	n = 0;
    do{
		n++;
		// apply exp(-t H), sebanyak t = NM delta t  
        for(m = 1; m <= NM; m++){
		    // Update psi //
		    for(i = 1; i < NX; i++){
		    for(j = 1; j < NX; j++){
		    for(k = 1; k < NX; k++){
	            psinew[i][j][k] = psi[i][j][k];
			    psinew[i][j][k] += dtdx2*(psi[i-1][j][k] - 2*psi[i][j][k] + psi[i+1][j][k]);
			    psinew[i][j][k] += dtdx2*(psi[i][j-1][k] - 2*psi[i][j][k] + psi[i][j+1][k]);
			    psinew[i][j][k] += dtdx2*(psi[i][j][k-1] - 2*psi[i][j][k] + psi[i][j][k+1]);
		    }}}

		    // save for next iteration
		    for(i = 1; i < NX; i++){
		    for(j = 1; j < NX; j++){
		    for(k = 1; k < NX; k++){
			    psi[i][j][k] = psinew[i][j][k];
		    }}}
	    }
		
		// apply psinew =  H psi //
		for(i = 1; i < NX; i++){
		for(j = 1; j < NX; j++){
		for(k = 1; k < NX; k++){
		    psinew[i][j][k] = (-0.5/dx2)*(psi[i-1][j][k] - 2*psi[i][j][k] + psi[i+1][j][k]);
		    psinew[i][j][k] += (-0.5/dx2)*(psi[i][j-1][k] - 2*psi[i][j][k] + psi[i][j+1][k]);
		    psinew[i][j][k] += (-0.5/dx2)*(psi[i][j][k-1] - 2*psi[i][j][k] + psi[i][j][k+1]);
		}}}
		
	    // save for next iteration
	    for(i = 1; i < NX; i++){
	    for(j = 1; j < NX; j++){
	    for(k = 1; k < NX; k++){
		    psi[i][j][k] = psinew[i][j][k];
	    }}}

        // Normalisasi
        temp = 0.0;
	    for(i = 1; i < NX; i++){
	    for(j = 1; j < NX; j++){
	    for(k = 1; k < NX; k++){
	       temp += psi[i][j][k]*psi[i][j][k];
        }}}
        temp = sqrt(temp*dx3);
	    for(i = 1; i < NX; i++){
	    for(j = 1; j < NX; j++){
	    for(k = 1; k < NX; k++){
	       psi[i][j][k] = psi[i][j][k]/temp;
        }}}
		// Compute Energy
	    energy = 0.0;
	    for(i = 1; i < NX; i++){
	    for(j = 1; j < NX; j++){
	    for(k = 1; k < NX; k++){
		    energy += (-0.5/dx2)*(psi[i-1][j][k] - 2*psi[i][j][k] + psi[i+1][j][k])*psi[i][j][k];
		    energy += (-0.5/dx2)*(psi[i][j-1][k] - 2*psi[i][j][k] + psi[i][j+1][k])*psi[i][j][k];
		    energy += (-0.5/dx2)*(psi[i][j][k-1] - 2*psi[i][j][k] + psi[i][j][k+1])*psi[i][j][k];
		}}}
		energy *= dx3;
		
		de = fabs(energy - oldenergy);
		oldenergy = energy;

		//printf("%ld, %lf \n", n, energy);
		
    }while(de > 1.0E-8);
	
	printf("%ld, %lf\n", n, energy);
	

	// Save Results
	outfile = fopen("psi.cube", "w");
	//for(i = 0; i <= NX; i++){
	//	fprintf(outfile, "%le %le \n", i*dx, psi[i]);
	//}

	// create cube file
	fprintf(outfile,"1st line: Comments \n");
	fprintf(outfile,"2nd line is also a coment line \n");
	//
	fprintf(outfile,"%ld    0.000000    0.000000    0.000000\n", 1);
	fprintf(outfile,"%ld    %8.6lf    0.000000    0.000000\n", NX+1, dx);
	fprintf(outfile,"%ld    0.000000    %8.6lf    0.000000\n", NX+1, dx);
	fprintf(outfile,"%ld    0.000000    0.000000    %8.6lf\n", NX+1, dx);
	fprintf(outfile,"1    0.000000    0.000000    0.000000    0.000000\n");
	//fprintf(outfile,"1    0.000000    0.000000    0.000000    0.000000\n");
	//fprintf(outfile,"1    0.000000    0.000000    0.000000    0.000000\n");
	//
	for(i = 0; i <= NX; i++) {
		for(j = 0; j <= NX; j++) {
			for(k = 0; k <= NX; k++) {
				fprintf(outfile,"%g ",psi[i][j][k]);
				if (k % 6 == 5)
					fprintf(outfile,"\n");
				}
			fprintf(outfile,"\n");
		}
	}
	fclose(outfile);

	
    return 0;	
}