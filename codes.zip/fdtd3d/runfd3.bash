#!/bin/bash
# run code
for i in {55.4,55.6,55.8,56,56.2,56.4,56.6,56.8,57,57.2,57.4,57.6}
do
   echo $i  
   ./new3.exe $i >> hasil_Ep3c.dat
done