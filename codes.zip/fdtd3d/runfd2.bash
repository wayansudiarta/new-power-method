#!/bin/bash
# run code
#./new3.exe 52 >> hasil_Ep3.dat
for ((i = 71 ; i <= 80 ; i++)); do
   echo $i  
   ./new3.exe $i >> hasil_Ep3.dat
done