#!/bin/bash
# run code
./new3.exe 1 > hasil_Ep3.dat
for ((i = 2 ; i < 50 ; i++)); do
   echo $i  
   ./new3.exe $i >> hasil_Ep3.dat
done